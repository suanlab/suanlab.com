a, b = 6, 4
a += b      # a에서 b를 더한 값을 a에 대입
print(a)
a -= b      # a에서 b를 뺀 값을 a에 대입
print(a)
a *= b      # a와 b와 곱한 값을 a에 대입
print(a)
a /= b      # a를 b로 나눈 값을 a에 대입
print(a)
a %= b      # a를 b로 나눈 나머지 값을 a에 대입
print(a)
a **= b     # a를 b만큼 제곱한 값을 a에 대입
print(a)
a //= b     # a를 b로 나눈 몫을 a에 대입
print(a)