print(float(True))
print(float(10))
print(float('10'))