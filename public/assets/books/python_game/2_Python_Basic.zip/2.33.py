for i in range(0, 3):   # i가 0부터 3이 되기 전까지 (0, 1, 2)
    print(i)
    print("적 등장!")