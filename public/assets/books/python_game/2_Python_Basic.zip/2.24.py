a = 6
b = 4
print(a + b)    # 덧셈
print(a - b)    # 뺄셈
print(a * b)    # 곱셉
print(a / b)    # 나눗셈
print(a % b)    # 나머지
print(a ** b)   # 제곱
print(a // b)   # 몫