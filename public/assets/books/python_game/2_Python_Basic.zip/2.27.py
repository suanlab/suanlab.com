a, b = 6, 4
print(5 < a and 5 < b)      # a가 5보다 크고(and) b가 5보다 크면 True
print(5 < a or 5 < b)       # a가 5보다 크거나(or) b가 5보다 크면 True
print(5 < a and not 5 < b)  # a가 5보다 크고(and) b가 5보다 크지 않으면(not) True
print(5 < a or not 5 < b)   # a가 5보다 크거나(or) b가 5보다 크지 않으면(not) True 
