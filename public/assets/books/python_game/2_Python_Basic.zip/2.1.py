name = "Suan"
print(name)
num = 123
print(num)
