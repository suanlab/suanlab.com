def fire():
    print("미사일 발사!")

fire()
fire()
fire()