print(round(0.6))           # 소수점 이하 반올림
print(round(0.4))           # 소수점 이하 반올림
print(round(3.14))          # 소수점 이하 반올림
print(round(3.141527, 2))   # 소수점 이하 둘째 자릿수 기준으로 반올림
