a, b = 6, 4
l = [2, 4, 8]
print(a in l)       # a가 l 안에 있으면(in) True
print(b in l)       # b가 l 안에 있으면(in) True
print(a not in l)   # a가 l 안에 없으면(not in) True
print(b not in l)   # b가 l 안에 없으면(not in) True
