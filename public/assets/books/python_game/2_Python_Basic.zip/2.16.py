print(int(True))
print(int(12.34))
print(int('10'))