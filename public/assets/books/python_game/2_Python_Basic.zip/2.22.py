print(pow(2, 3))    # 2의 3제곱
print(pow(10, 4))   # 10의 4제곱
