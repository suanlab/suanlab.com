key = "RIGHT"
if key == "LEFT":
    print("왼쪽으로 이동")
elif key == "RIGHT":
    print("오른쪽으로 이동")
else:
    print("정지")