def add(n1, n2):
    return n1 + n2

r = add(3, 5)
print(r)
print(add(4, 7))