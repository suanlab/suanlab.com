enemy = ["적1", "적2", "적3"]
for e in enemy: # 리스트 enemy를 순회하며 반복
    print(e)