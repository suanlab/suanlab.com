s = "String"
print(s)

print(s[0])
print(s[1])
print(s[2])

print(s[-6])
print(s[-5])
print(s[-4])