import random

print(random.random())
print(random.randint(1, 10))

for i in range(0, 10, 2):
    print(i)

print(random.randrange(0, 10, 2))