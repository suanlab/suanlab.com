a, b = 6, 4
print(a is b)       # a가 b와 같은 값이면 True
print(a is not b)   # a가 b와 같지 않은 값이면 True
a, b = 5, 5
print(a is b)       # a가 b와 같은 값이면 True
print(a is not b)   # a가 b와 같지 않은 값이면 True
