b = True
print(b)
print(type(b))
