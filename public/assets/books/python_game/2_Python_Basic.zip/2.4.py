f = 12.34
print(f)
print(type(f))