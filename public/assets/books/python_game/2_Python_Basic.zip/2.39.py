def sum(*li):
    sum = 0
    for i in li:
        sum += i
    return sum

print(sum(1, 2, 3, 4, 5))
print(sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))