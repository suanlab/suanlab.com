print(abs(-4))  # -4의 절대값
print(abs(5))   # 5의 절대값
