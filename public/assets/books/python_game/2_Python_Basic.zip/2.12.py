units = 151
score = 421
stamina = "89%"
life = "2개"

print(f"파괴한 유닛수: {units}, 점수: {score}")
print(f"체력: {stamina}, 목숨: {life}")