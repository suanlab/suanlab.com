def fire(n=3):
    for i in range(0, n):
        print("미사일 발사!")

fire()
fire(2)