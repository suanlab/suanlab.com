print('Hello')
print("파이썬은 재미있다.")
print('''파이썬은 심플하다.''')
print("""파이썬은 문자열 처리가 뛰어나다""")
