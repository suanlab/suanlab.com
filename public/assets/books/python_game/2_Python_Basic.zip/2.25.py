a, b = 6, 4
print(a == b)   # a와 b가 같으면 True
print(a != b)   # a와 b가 다르면 True
print(a > b)    # a가 b보다 크면 True
print(a < b)    # a가 b보다 작으면 True
print(a >= b)   # a가 b보다 크거나 같으면 True
print(a <= b)   # a가 b보다 작거나 같으면 True