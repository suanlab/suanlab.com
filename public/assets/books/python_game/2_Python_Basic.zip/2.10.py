s = "이수안컴퓨터연구소"
print(s)
print(s[0:3])
print(s[:3])
print(s[3:6])
print(s[-6:-3])
print(s[-3:])