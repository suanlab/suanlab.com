i = 10
print(i)
print(type(i))
