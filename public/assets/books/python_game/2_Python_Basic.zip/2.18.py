print(str(10))
print(str(12.34))
print(str([1, 2, 3]))
print(str({1: 'One', 2: 'Two'}))
