s1 = "Suan"
s2 = "Lab"
print(s1 + s2)
print(s1 * 3)
print(len(s1))
print(len(s1 + s2))