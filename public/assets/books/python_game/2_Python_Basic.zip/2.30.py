fire = True
if fire:    # 조건문
    print("미사일 발사!")
